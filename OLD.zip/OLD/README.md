# Foody
A web based application for food delivery system called Foody.
